package com.nagarro.librarymanagment.apicall;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.librarymanagment.model.Author;
import com.nagarro.librarymanagment.model.Book;

@Service
public class CallApi {

	@Autowired
	HttpHeaders headers;

	@Autowired
	RestTemplate restTemplate;

	public boolean addBook(Book book) throws URISyntaxException {
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Book> entity = new HttpEntity<Book>(book, headers);
		boolean status = restTemplate.exchange(Constant.ADD_BOOK_URI, HttpMethod.POST, entity, Boolean.class).getBody();

		return status;
	}

	public boolean updateBook(Book book) throws URISyntaxException {

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Book> entity = new HttpEntity<Book>(book, headers);

		boolean status = restTemplate.exchange(Constant.UPDATE_BOOK_URI, HttpMethod.PUT, entity, Boolean.class)
				.getBody();

		return status;
	}

	public Book getBookById(int bookId) {

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Integer> entity = new HttpEntity<Integer>(bookId, headers);

		Book book= restTemplate.exchange(Constant.BOOK_URI + bookId, HttpMethod.GET, entity, Book.class)
				.getBody();
		
		return book;
	}
	
	
	public boolean deleteBook(int bookId) {

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Integer> entity = new HttpEntity<Integer>(bookId, headers);

		boolean status = restTemplate.exchange(Constant.BOOK_URI + bookId, HttpMethod.DELETE, entity, Boolean.class)
				.getBody();
		return status;
	}

	public List<Book> getAllBook() throws URISyntaxException {

		URI uri = new URI(Constant.BOOK_URI);

		RequestEntity<List<Book>> reqEntity = new RequestEntity<>(headers, HttpMethod.GET, uri);
		ParameterizedTypeReference<List<Book>> typeRef = new ParameterizedTypeReference<List<Book>>() {
		};

		
		ResponseEntity<List<Book>> resEntity = restTemplate.exchange(reqEntity, typeRef);
		
		return resEntity.getBody();

	}

	public List<Author> getAllAuthor() throws URISyntaxException {

		URI uri = new URI(Constant.AUTHOR_URI);

		RequestEntity<List<Author>> reqEntity = new RequestEntity<>(headers, HttpMethod.GET, uri);
		ParameterizedTypeReference<List<Author>> typeRef = new ParameterizedTypeReference<List<Author>>() {
		};

		ResponseEntity<List<Author>> resEntity = restTemplate.exchange(reqEntity, typeRef);

		return resEntity.getBody();
	}

}
