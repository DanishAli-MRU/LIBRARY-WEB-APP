package com.nagarro.librarymanagment.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.librarymanagment.dao.daoImpl.UserDaoImpl;
import com.nagarro.librarymanagment.model.User;
import com.nagarro.librarymanagment.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDaoImpl userDaoImpl;

	public User checkUser(String email, String password) {

		User user = userDaoImpl.authenticateUser(email, password);

		return user;
	}

	

}
