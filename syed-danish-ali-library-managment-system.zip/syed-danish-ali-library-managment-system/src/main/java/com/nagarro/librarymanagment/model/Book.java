package com.nagarro.librarymanagment.model;

import java.text.ParseException;
import java.util.Date;

import com.nagarro.librarymanagment.util.FormatDate;

public class Book {

	private int bookId;

	private String bookName;

	private Date addedOnDate;

	private Author author;

	public Book(int bookId, String bookName, Author author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
	}

	public Book(int bookId, String bookName, Date addedOnDate, Author author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.addedOnDate = addedOnDate;
		this.author = author;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBookId() {
		return bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public Date getAddedOnDate() {

		return addedOnDate;
	}

	public Author getAuthor() {
		return author;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public void setAddedOnDate(Date addedOnDate) {

		this.addedOnDate = addedOnDate;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public String getDate() throws ParseException {
		return FormatDate.formatDate(addedOnDate);
	}

}
