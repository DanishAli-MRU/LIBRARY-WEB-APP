package com.nagarro.librarymanagment.controller;

import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.librarymanagment.apicall.CallApi;
import com.nagarro.librarymanagment.constant.Constant;
import com.nagarro.librarymanagment.message.Message;

@RestController
public class DeleteBook {
	
	@Autowired
	CallApi apiCall;
	
	@GetMapping(path=Constant.DELETEBOOK_CONTROLLER)
	public ModelAndView deleteBookById(@RequestParam(Constant.BOOK_ID)int bookId,HttpServletRequest req) throws URISyntaxException{
		
		ModelAndView modelAndView = new ModelAndView("redirect:/"+Constant.SHOW_BOOK_CONTROLLER) ;
		
		boolean status=apiCall.deleteBook(bookId);
		
		HttpSession session=req.getSession();
		
		if(status){
			Message sucessMsg=new Message(Constant.DELETE_SUCESSFULLY, Constant.MSG_CSS_SUCESS);
			session.setAttribute(Constant.MESSAGE, sucessMsg);
		}else{
			Message failedMsg=new Message(Constant.DELETE_FAILED, Constant.MSG_CSS_FAIL);
			session.setAttribute(Constant.MESSAGE, failedMsg);
		}
		
		return modelAndView ;
	}

}
