package com.nagarro.librarymanagment.controller;

import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.librarymanagment.apicall.CallApi;
import com.nagarro.librarymanagment.constant.Constant;


@RestController
public class ShowBook {

	@Autowired
	CallApi apiCall;
	
	
	@GetMapping(path=Constant.SHOW_BOOK_CONTROLLER)
	public ModelAndView getShowTshirt() throws URISyntaxException{
		
		ModelAndView modelAndView = new ModelAndView(Constant.BOOK_JSP) ;
		modelAndView.addObject(Constant.BOOK_LIST, apiCall.getAllBook());
		
		
		return modelAndView ;
	}
	
		
		
	

}
