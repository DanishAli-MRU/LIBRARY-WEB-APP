package com.nagarro.librarymanagment.apicall;

public class Constant {
	
	public final static String BOOK_URI="http://localhost:8090/book/";
	public final static String ADD_BOOK_URI="http://localhost:8090/book/addBook";
	public final static String UPDATE_BOOK_URI="http://localhost:8090/book/updateBook";
	public final static String AUTHOR_URI="http://localhost:8090/author";
}
