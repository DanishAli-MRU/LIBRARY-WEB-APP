package com.nagarro.librarymanagment.service;

import com.nagarro.librarymanagment.model.User;

public interface UserService {
	
	 User checkUser(String email, String password);
}
