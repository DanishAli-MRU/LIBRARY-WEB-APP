package com.nagarro.librarymanagment.controller;

import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.librarymanagment.apicall.CallApi;
import com.nagarro.librarymanagment.constant.Constant;
import com.nagarro.librarymanagment.message.Message;
import com.nagarro.librarymanagment.model.Author;
import com.nagarro.librarymanagment.model.Book;

@RestController
public class AddBook {
	
	@Autowired
	CallApi apiCall;
	
	@GetMapping(path=Constant.ADDBOOK_CONTROLLER)
	public ModelAndView getAddBookJsp() throws URISyntaxException{
		
		ModelAndView modelAndView = new ModelAndView(Constant.ADDBOOK_JSP) ;
		modelAndView.addObject(Constant.AUTHOR_LIST,apiCall.getAllAuthor());
		
		return modelAndView ;
	}
	
	@PostMapping(path=Constant.ADDBOOK_CONTROLLER)
	public ModelAndView addBook(@ModelAttribute("book")Book book,HttpServletRequest req) throws URISyntaxException {
		
		ModelAndView modelAndView = new ModelAndView("redirect:/"+Constant.SHOW_BOOK_CONTROLLER) ;
		HttpSession session=req.getSession();
		
		int authorId=Integer.parseInt(req.getParameter(Constant.AUTHOR_ID));
		book.setAuthor(new Author(authorId));
		
		boolean status=apiCall.addBook(book);
		
		
		if(status) {
			Message sucessMsg=new Message(Constant.SAVED_SUCESSFULLY, Constant.MSG_CSS_SUCESS);
			session.setAttribute(Constant.MESSAGE, sucessMsg);
		}else {
			Message failedMsg=new Message(Constant.SAVING_FAILED, Constant.MSG_CSS_FAIL);
			session.setAttribute(Constant.MESSAGE, failedMsg);
		}
		
		return modelAndView;
	}

}
