package com.nagarro.librarymanagment.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FormatDate {

	public static String formatDate(Date date) throws ParseException {

		SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");

		String formatedDate = formatter2.format(date);

		return formatedDate;
	}

}
