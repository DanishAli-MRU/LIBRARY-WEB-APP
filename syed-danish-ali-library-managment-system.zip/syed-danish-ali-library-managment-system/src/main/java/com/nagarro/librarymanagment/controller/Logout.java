package com.nagarro.librarymanagment.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.librarymanagment.constant.Constant;
import com.nagarro.librarymanagment.message.Message;

@RestController
public class Logout {
	
	

	@GetMapping(path=Constant.LOGOUT_CONTROLLER)
	public ModelAndView logout(HttpServletRequest request) throws IOException {

		HttpSession session = request.getSession();
		session.removeAttribute(Constant.CURRENT_USER_SESSION);

		Message logoutMsg = new Message(Constant.LOGOUT_SUCESSFULLY, Constant.MSG_CSS_SUCESS);
		session.setAttribute(Constant.MESSAGE, logoutMsg);


		return new ModelAndView("redirect:"+Constant.LOGIN_CONTROLLER);


	}

}
