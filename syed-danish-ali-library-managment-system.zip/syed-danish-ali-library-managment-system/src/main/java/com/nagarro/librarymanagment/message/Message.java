package com.nagarro.librarymanagment.message;

public class Message {

	private String content;

	private String msgCss;

	public Message() {

	}

	public Message(String content, String msgCss) {
		this.content = content;

		this.msgCss = msgCss;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getMsgCss() {
		return msgCss;
	}

	public void setMsgCss(String msgCss) {
		this.msgCss = msgCss;
	}

}
