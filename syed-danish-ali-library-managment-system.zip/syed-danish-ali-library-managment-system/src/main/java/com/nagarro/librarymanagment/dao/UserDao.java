package com.nagarro.librarymanagment.dao;

import com.nagarro.librarymanagment.model.User;

public interface UserDao {

	User authenticateUser(String userName, String password);
}
