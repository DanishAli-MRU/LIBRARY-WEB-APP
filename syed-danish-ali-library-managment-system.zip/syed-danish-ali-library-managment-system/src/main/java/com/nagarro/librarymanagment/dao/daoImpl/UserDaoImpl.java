package com.nagarro.librarymanagment.dao.daoImpl;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.nagarro.librarymanagment.converter.Converter;
import com.nagarro.librarymanagment.dao.UserDao;
import com.nagarro.librarymanagment.entity.UserEntity;
import com.nagarro.librarymanagment.model.User;

@Repository
public class UserDaoImpl implements UserDao{


	private final String CHECK_USER_QUERY = "from user where userName=:userName";

	
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	

	public User authenticateUser(String userName, String password) {

		Session sesion = hibernateTemplate.getSessionFactory().openSession();
		User user = null;
		try {

			Query<UserEntity> userQuery = sesion.createQuery(CHECK_USER_QUERY, UserEntity.class);
			userQuery.setParameter("userName", userName);

			UserEntity userEntity = (UserEntity) userQuery.uniqueResult();

			if (userEntity != null && password.equals(userEntity.getPassword())) {
				Converter converter = new Converter();
				user = converter.convertUserEntityToUserBean(userEntity);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sesion.close();
		}
		return user;

	}

	
}
