package com.nagarro.librarymanagment.constant;

public class Constant {


	public static final String USER_TABLE = "userinfo";
	public static final String USER_ENTITY = "user";
	public static final String ENTITY_PACKAGE ="com.nagarro.librarymanagment.entity";
	
	public static final String DB_DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/libmanagment";
	public static final String DB_ID = "root";
	public static final String DB_PASSWORD = "root";
	public static final String DB_DIALECT = "org.hibernate.dialect.MySQL8Dialect";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String UPDATE = "update";

	public static final String USER_ID = "id";
	public static final String AUTHOR_ID ="id";
	public static final String BOOK_ID ="bookId";
	public static final String USER_EMAIL = "email";
	public static final String USER_UNAME = "userName";
	public static final String USER_NAME = "name";
	public static final String USER_PASSWORD = "password";
	public static final String USER_SECURITYKEY = "securitykey";
	public static final String USER_GENDER = "gender";
	public static final String FORM_CHECKED = "check";
	public static final String CURRENT_USER_SESSION = "currentUserSession";
	
	
	public static final String LOGIN_FAILED="wrong credentials";
	public static final String LOGOUT_SUCESSFULLY="Logout Successfully";
	
	public static final String SAVING_FAILED="Book Is Already Present With Same Book Code , Cant Add";
	public static final String SAVED_SUCESSFULLY="Book Added Successfully";
	
	public static final String EDIT_FAILED="Cant' Edit";
	public static final String EDIT_SUCESSFULLY="Book Editted Successfully";
	
	public static final String DELETE_FAILED="Cant' Delete";
	public static final String DELETE_SUCESSFULLY="Book Deleted Successfully";
	
	public static final String MESSAGE="msg";
	public static final String MSG_CSS_SUCESS="alert-primary";
	public static final String MSG_CSS_FAIL="alert-danger";
	
	public static final String LOGIN_JSP="login.jsp";
	public static final String ADDBOOK_JSP="addbook.jsp";
	public static final String EDITBOOK_JSP="editbook.jsp";
	public static final String BOOK_JSP="book.jsp";
	public static final String ADDBOOK_CONTROLLER="Addbook";
	public static final String DELETEBOOK_CONTROLLER="Deletebook";
	public static final String EDITBOOK_CONTROLLER="Editbook";
	public static final String LOGIN_CONTROLLER="Login";
	public static final String LOGOUT_CONTROLLER="Logout";
	public static final String SHOW_BOOK_CONTROLLER="showBook";
	
	public static final String AUTHOR_LIST="listOfAuthor";
	public static final String BOOK_LIST="listOfBook";
	public static final String BASE_PACKAGE="com.nagarro.librarymanagment";
}

