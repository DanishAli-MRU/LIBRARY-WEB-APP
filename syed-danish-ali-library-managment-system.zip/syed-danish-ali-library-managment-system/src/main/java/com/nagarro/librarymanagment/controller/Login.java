package com.nagarro.librarymanagment.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.librarymanagment.constant.Constant;
import com.nagarro.librarymanagment.message.Message;
import com.nagarro.librarymanagment.model.User;
import com.nagarro.librarymanagment.service.serviceimpl.UserServiceImpl;

@RestController
public class Login {
	
	@Autowired
	UserServiceImpl service;
	
	
	@GetMapping(path=Constant.LOGIN_CONTROLLER)
	public ModelAndView getlogin(){
		ModelAndView modelAndView = new ModelAndView(Constant.LOGIN_JSP) ;
		return modelAndView ;
	}
	
	
	@PostMapping(value=Constant.LOGIN_CONTROLLER)
	public ModelAndView login(@ModelAttribute("user")User user,HttpServletRequest request) throws Exception {
		
		HttpSession session=request.getSession();
		
		ModelAndView mv;
		
		User currentUser=service.checkUser(user.getUserName(),user.getPassword());
		
		if(currentUser!=null) {
			session.setAttribute(Constant.CURRENT_USER_SESSION, currentUser);

			
			mv=new ModelAndView("redirect:/"+Constant.SHOW_BOOK_CONTROLLER);

			
		}else {
			Message errormsg=new Message(Constant.LOGIN_FAILED, Constant.MSG_CSS_FAIL);
          
			session.setAttribute(Constant.MESSAGE, errormsg);
			mv=new ModelAndView("redirect:/"+Constant.LOGIN_CONTROLLER);
            
		}
		
		
		return mv;

	}


}
