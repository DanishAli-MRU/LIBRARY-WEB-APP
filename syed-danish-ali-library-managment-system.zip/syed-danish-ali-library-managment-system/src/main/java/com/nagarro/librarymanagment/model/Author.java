package com.nagarro.librarymanagment.model;

public class Author {

	private int id;

	private String name;

	public Author() {
		super();
	}

	public Author(String name) {
		super();
		
		this.name = name;
	}
	
	public Author(int id) {
		super();
		this.id = id;
		
	}
	
	public Author(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
