package com.nagarro.librarymanagment.converter;

import com.nagarro.librarymanagment.entity.UserEntity;
import com.nagarro.librarymanagment.model.User;

public class Converter {
	
	public UserEntity convertUserBeanToUserEntity(User user) {
		UserEntity userEntity = new UserEntity();
		userEntity.setName(user.getName());
		userEntity.setEmail(user.getEmail());
		userEntity.setPassword(user.getPassword());
		userEntity.setGender(user.getGender());
		userEntity.setSecurityKey(user.getSecurityKey());

		return userEntity;
	}

	public User convertUserEntityToUserBean(UserEntity userEntity) {
		User user = new User();
		user.setId(userEntity.getId());
		user.setName(userEntity.getName());
		user.setEmail(userEntity.getEmail());
		user.setPassword(userEntity.getPassword());
		user.setGender(userEntity.getGender());
		user.setSecurityKey(userEntity.getSecurityKey());

		return user;
	}
	
	
	

}